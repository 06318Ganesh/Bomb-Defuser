let defuserEl = document.getElementById("defuser");
let timerEl = document.getElementById("timer");

let countdown = 10;

let intervalId = setInterval(function() {
    countdown = countdown - 1
    timerEl.textContent = countdown;

    if (countdown === 0) {
        timerEl.textContent = "Bhoom";
        clearInterval(intervalId);
    }
}, 1000);
defuserEl.addEventListener("keydown", function(event) {
    let bombDefuserText = defuserEl.value;

    if (event.key === "Enter" && bombDefuserText === "defuser" && countdown !== 0) {
        timerEl.textContent = "you did it";
        clearInterval(intervalId);
    }
})